package com.example.uas

data class ImageData (
    val imageUrl : String
)