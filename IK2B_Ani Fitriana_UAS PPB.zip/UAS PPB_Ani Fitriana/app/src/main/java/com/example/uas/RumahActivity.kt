package com.example.uas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RumahActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rumah)
    }
}